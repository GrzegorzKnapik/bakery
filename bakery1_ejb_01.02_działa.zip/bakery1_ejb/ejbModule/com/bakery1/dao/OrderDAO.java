package com.bakery1.dao;

import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.bakery1.entities.Order;
import com.bakery1.entities.OrdersProduct;


//DAO - Data Access Object for Person entity
//Designed to serve as an interface between higher layers of application and data.
//Implemented as stateless Enterprise Java bean - server side code that can be invoked even remotely.

@Stateless
public class OrderDAO {
	private final static String UNIT_NAME = "bakery1-simplePU";
	
	// Dependency injection (no setter method is needed)
	@PersistenceContext(unitName = UNIT_NAME)
	protected EntityManager em;
	
	public void createOrdersProduct(OrdersProduct ordersProduct) {
		em.persist(ordersProduct);
	}

	public void create(Order order) {
		em.persist(order);
	}

	public Order createAndReturn(Order order) {
		em.persist(order);
		//em.flush();
		return order;
	}

	public Order merge(Order order) {
		return em.merge(order);
	}

	public void remove(Order order) {
		em.remove(em.merge(order));
	}

	public Order find(Object id) {
		return em.find(Order.class, id);
	}

	public List<Order> getFullList() {
		List<Order> list = null;

		Query query = em.createQuery("select o from Order o");

		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	public List<Order> getList(Map<String, Object> searchParams) {
		List<Order> list = null;

		// 1. Build query string with parameters
		String select = "select o ";
		String from = "from Order o ";
		String where = "";
		String orderby = "order by o.surname asc, o.name";

		// search for login
		Integer numberLogin = (Integer) searchParams.get("numberLogin");
		if (numberLogin != null) {
			if (where.isEmpty()) {
				where = "where ";
			} else {
				where += "and ";
			}
			where += "p.numberLogin like :numberLogin ";
		}
		
		//search for password
		String password = (String) searchParams.get("password");
		if (password != null) {
			if (where.isEmpty()) {
				where = "where ";
			} else {
				where += "and ";
			}
			where += "p.password like :password ";
		}
		
		
		
		// 2. Create query object
		Query query = em.createQuery(select + from + where);

		// 3. Set configured parameters
		
		
		if (password != null) {
			query.setParameter("password", password);
		}
		
		if (numberLogin != null) {
			query.setParameter("numberLogin", numberLogin);
		}

		// ... other parameters ... 

		// 4. Execute query and retrieve list of Person objects
		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
	
	
	

}
