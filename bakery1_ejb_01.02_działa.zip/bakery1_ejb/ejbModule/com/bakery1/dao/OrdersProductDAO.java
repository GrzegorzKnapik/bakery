package com.bakery1.dao;

import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.bakery1.entities.OrdersProduct;


//DAO - Data Access Object for Person entity
//Designed to serve as an interface between higher layers of application and data.
//Implemented as stateless Enterprise Java bean - server side code that can be invoked even remotely.

@Stateless
public class OrdersProductDAO {
	private final static String UNIT_NAME = "bakery1-simplePU";
	
	// Dependency injection (no setter method is needed)
	@PersistenceContext(unitName = UNIT_NAME)
	protected EntityManager em;
	


	public void create(OrdersProduct ordersProduct) {
		em.persist(ordersProduct);
	}

	public OrdersProduct createAndReturn(OrdersProduct ordersProduct) {
		em.persist(ordersProduct);
		//em.flush();
		return ordersProduct;
	}

	public OrdersProduct merge(OrdersProduct ordersProduct) {
		return em.merge(ordersProduct);
	}

	public void remove(OrdersProduct ordersProduct) {
		em.remove(em.merge(ordersProduct));
	}

	public OrdersProduct find(Object id) {
		return em.find(OrdersProduct.class, id);
	}

	public List<OrdersProduct> getFullList() {
		List<OrdersProduct> list = null;

		Query query = em.createQuery("select o from Order o");

		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	public List<OrdersProduct> getList(Map<String, Object> searchParams) {
		List<OrdersProduct> list = null;

		// 1. Build query string with parameters
		String select = "select o ";
		String from = "from Order o ";
		String where = "";
		String orderby = "order by o.surname asc, o.name";

		// search for login
		Integer numberLogin = (Integer) searchParams.get("numberLogin");
		if (numberLogin != null) {
			if (where.isEmpty()) {
				where = "where ";
			} else {
				where += "and ";
			}
			where += "p.numberLogin like :numberLogin ";
		}
		
		//search for password
		String password = (String) searchParams.get("password");
		if (password != null) {
			if (where.isEmpty()) {
				where = "where ";
			} else {
				where += "and ";
			}
			where += "p.password like :password ";
		}
		
		
		
		// 2. Create query object
		Query query = em.createQuery(select + from + where);

		// 3. Set configured parameters
		
		
		if (password != null) {
			query.setParameter("password", password);
		}
		
		if (numberLogin != null) {
			query.setParameter("numberLogin", numberLogin);
		}

		// ... other parameters ... 

		// 4. Execute query and retrieve list of Person objects
		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
	
	
	

}
