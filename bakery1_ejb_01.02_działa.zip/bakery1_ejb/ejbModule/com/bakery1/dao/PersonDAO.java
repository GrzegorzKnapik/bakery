package com.bakery1.dao;

import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.bakery1.entities.Person;


//DAO - Data Access Object for Person entity
//Designed to serve as an interface between higher layers of application and data.
//Implemented as stateless Enterprise Java bean - server side code that can be invoked even remotely.

@Stateless
public class PersonDAO {
	private final static String UNIT_NAME = "bakery1-simplePU";
	
	// Dependency injection (no setter method is needed)
	@PersistenceContext(unitName = UNIT_NAME)
	protected EntityManager em;
	


	public void create(Person person) {
		em.persist(person);		
	}

	public Person createAndReturn(Person person) {
		em.persist(person);
		//em.flush();
		return person;
	}

	public Person merge(Person person) {
		return em.merge(person);
	}

	public void remove(Person person) {
		em.remove(em.merge(person));
	}

	public Person find(Object id) {
		return em.find(Person.class, id);
	}

	public List<Person> getFullList() {
		List<Person> list = null;

		Query query = em.createQuery("select p from Person p");

		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	public List<Person> getList(Map<String, Object> searchParams) {
		List<Person> list = null;

		// 1. Build query string with parameters
		String select = "select p ";
		String from = "from Person p ";
		String where = "";
		String orderby = "order by p.surname asc, p.name";

		// search for login
		Integer numberLogin = (Integer) searchParams.get("numberLogin");
		if (numberLogin != null) {
			if (where.isEmpty()) {
				where = "where ";
			} else {
				where += "and ";
			}
			where += "p.numberLogin like :numberLogin ";
		}
		
		//search for password
		String password = (String) searchParams.get("password");
		if (password != null) {
			if (where.isEmpty()) {
				where = "where ";
			} else {
				where += "and ";
			}
			where += "p.password like :password ";
		}
		
		
		
		// 2. Create query object
		Query query = em.createQuery(select + from + where);

		// 3. Set configured parameters
		
		
		if (password != null) {
			query.setParameter("password", password);
		}
		
		if (numberLogin != null) {
			query.setParameter("numberLogin", numberLogin);
		}

		// ... other parameters ... 

		// 4. Execute query and retrieve list of Person objects
		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
	
	
	
	public List<Person> getListLoginRepeat(Map<String, Object> searchParams) {
		List<Person> list = null;

		// 1. Build query string with parameters
		String select = "select p ";
		String from = "from Person p ";
		String where = "";
		String orderby = "order by p.surname asc, p.name";

		// search for surname
		Integer numberLogin = (Integer) searchParams.get("numberLogin");
		if (numberLogin != null) {
			if (where.isEmpty()) {
				where = "where ";
			} else {
				where += "and ";
			}
			where += "p.numberLogin like :numberLogin ";
		}
		
		// ... other parameters ... 
		//lub role.TypeRole
//tuti "from Person p where p.password='qwerty'"
		// 2. Create query object
		Query query = em.createQuery(select + from + where);

		// 3. Set configured parameters
		if (numberLogin != null) {
			query.setParameter("numberLogin", numberLogin);
		}

		// ... other parameters ... 

		// 4. Execute query and retrieve list of Person objects
		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	
	
	
	

}
