package com.bakery1.person;


import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.faces.simplesecurity.RemoteClient;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.servlet.http.HttpSession;

import javax.servlet.http.HttpServletRequest;
import com.bakery1.dao.PersonDAO;
import com.bakery1.entities.Person;
import com.bakery1.entities.Role;
import com.bakery1.dao.RoleDAO;

@Named
@ViewScoped
public class LoginBB implements Serializable {
	private static final long serialVersionUID = 1L;

	
	
	private static final String PAGE_HELLO = "hello?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;
	private static final String PAGE_REG = "personEdit?faces-redirect=true";
	private static final String PAGE_LOGIN = "login?faces-redirect=true";
	private static final String PAGE_SHOP = "shop?faces-redirect=true";
	
	
	
	private Person person = new Person();
	private Person loaded = null;

	@ManyToOne
	@JoinColumn(name = "roleID", nullable=false)
	private Role role;
	
	@EJB
	PersonDAO personDAO;
	
	@EJB
	RoleDAO roleDAO;

	@Inject
	FacesContext context;

	@Inject
	Flash flash;

	public Person getPerson() {
		return person;
	}
	
	
	private Integer login;
    
    private String password;
 
    public Integer getLogin() {
        return login;
    }
 
    public void setLogin(Integer login) {
        this.login = login;
    }
 
    public String getPassword() {
        return password;
    }
 
    public void setPassword(String password) {
        this.password = password;
    }
    
   
    
    
    public String doLogin() throws InterruptedException{
    	//generateHashedPassword(getPassword());
    	System.out.println(getLogin());
    	System.out.println(getPassword());
    	
    	FacesContext ctx = FacesContext.getCurrentInstance();
    	
    	// 1. verify login and password - get User from "database"
    	Map<String, Object> searchParams = new HashMap<String, Object>();
    	searchParams.put("numberLogin", person.getNumberLogin());
    	searchParams.put("password", person.getPassword());
    	
    	List<Person> personList = personDAO.getList(searchParams);
    	Person person = null;
    	
    	
    	if(!personList.isEmpty()) {
    		person = personList.get(0);
    		person.getRole().getTypeRole();
    		System.out.println(person.getRole().getTypeRole());
    		System.out.println(person.getRole());
    		System.out.println(person.getName());
    		ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Poprawnie zalogowano", null));
    		
    	}
    	// 2. if bad login or password - stay with error info
    	if(person == null) {
    		//ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, txtLogin.getString("invalidLogIn"), null));
    		ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Zły login lub hasło", null));
    		 return PAGE_STAY_AT_THE_SAME;
    	}
    	
    	
    	
    	
    	// 3. if logged in: get User roles, save in RemoteClient and store it in session
 		
 		RemoteClient<Person> client = new RemoteClient<Person>(); //create new RemoteClient
 		client.setDetails(person);
 		
 		 if (client.getDetails() == null) {
			 System.out.println("ssesssPrzed");
		 }
		 if (client.getDetails() != null) {
			 System.out.println("wwwdaPrzed");
		 }
 		
 		
 		//client.getRoles().add(person.getRole().getTypeRole());
 		client.getRoles().add(person.getRole().getTypeRole());
 		
 		System.out.println("dd");
 	
 		//zapis w sesji
 		//store RemoteClient with request info in session (needed for SecurityFilter)
 		HttpServletRequest request = (HttpServletRequest) ctx.getExternalContext().getRequest();
 		client.store(request);
 		
 		if (client.getDetails() == null) {
			 System.out.println("ssesssPo");
		 }
		 if (client.getDetails() != null) {
			 System.out.println("wwwdaPo");
		 }
 		
 		System.out.println("dd"+client.getRoles());
 		System.out.println(client.getLogin());
 		System.out.println(client.getName());
 		
 		// and enter the system (now SecurityFilter will pass the request)
 		return PAGE_SHOP;
 		
    	
 	}
 	//RemoteClient<Person> personRemote;
 	//RemoteClient<Person> newpersonRemote;
 	 
 	public String doLogout(){
 		
 		//HttpSession session = (HttpSession) context.getExternalContext().getSession(true);
		//loaded = (Person) session.getAttribute("person");
 		
 		//FacesContext facesContext = FacesContext.getCurrentInstance();
 		//HttpSession session = (HttpSession) facesContext.getExternalContext().getSession(true);
 		//newpersonRemote = personRemote.load(session);
 		
 		//loaded = (Person) session.getAttribute("person");
 		
 		//if (newpersonRemote == null) {
		//	 System.out.println("X");
		// }
 		//if (newpersonRemote != null) {
		//	 System.out.println("I");
		// }
 		
 		
 		
 		//if (loaded == null) {
		//	 System.out.println("X");
		// }
		
		//if (loaded != null) {
		//	 System.out.println("I");
		// }
 		
 		//old
 		
 		HttpSession session = (HttpSession) FacesContext.getCurrentInstance()
 				.getExternalContext().getSession(true);
 		//////
 		
 		
 		//personRemote.load(session);
 		
 		//if (personRemote.load(session) == null) {
 		//		 System.out.println("X");
 		//	 }
 		
 		//personRemote.getDetails();
 	
 		// if (personRemote.getDetails() == null) {
		//	 System.out.println("X");
		/// }
 		 
 		// if (personRemote.getDetails() != null) {
		///	 System.out.println("I");
		// }
 		
 		
 		
 		
 		// session.getAttribute("person");
 		 
 		// if (session.getAttribute("person") != null) {
		//	 System.out.println("adad");
		// }
 		// loaded = (Person) session.getAttribute("person");
		 
 		
 		
 		
		 
		
		// if (loaded == null) {
		//	 System.out.println("ssesss");
		// }
		// if (loaded != null) {
		//	 System.out.println("wwwda");
		// }
		 //////
 		//Invalidate session
 		// - all objects within session will be destroyed
 		// - new session will be created (with new ID)
 		session.invalidate();
 		return PAGE_LOGIN;
 	}
 	
 
}
