package com.bakery1.OrdersProduct;


import java.io.IOException;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.faces.simplesecurity.RemoteClient;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.bakery1.entities.Order;
import com.bakery1.entities.OrdersProduct;
import com.bakery1.entities.OrdersProductPK;
import com.bakery1.entities.Person;
import com.bakery1.entities.Product;
import com.bakery1.person.LoginBB;
import com.bakery1.dao.OrderDAO;
import com.bakery1.dao.PersonDAO;
import com.bakery1.dao.OrdersProductDAO;

@Named
@SessionScoped
public class ShopBB implements Serializable {
	private static final long serialVersionUID = 1L;

	private static final String PAGE_SHOPPING_CART = "shoppingCart?faces-redirect=true";
	private static final String PAGE_SHOP = "shop?faces-redirect=true";
	private static final String PAGE_HELLO = "hello?faces-redirect=true";
	private static final String PAGE_PERSON_LIST = "personList?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;
	
	
	private Order order = new Order();
	//private OrdersProduct ordersProduct = new OrdersProduct();
	private Person loaded = null;
	
	@Inject
	FacesContext context;
	
	
	@Inject
	Flash flash;
	
	@EJB
	OrderDAO orderDAO;
	
	@EJB
	OrderDAO ordersProductDAO;
	
	
	
	
	private HashMap<Integer,OrdersProduct> cart;
	
	
	@PostConstruct
	public void init() {
			this.cart = new HashMap<Integer,OrdersProduct>();
	}
	
	public HashMap<Integer,OrdersProduct> getItems() {
		return cart;
	}
	
	public List<OrdersProduct> getList() {
		ArrayList<OrdersProduct> list = new ArrayList<OrdersProduct>();
		cart.forEach((key, value) -> {
			list.add(value);
		});
		
		
		
		return list;
	}
	
	
	public String addToCart(Product p) {
		
		//1. czy istnieje już taki produkt
		
		if(cart.containsKey(p.getIdProducts())) {
			OrdersProduct prev_op = cart.get(p.getIdProducts());
			//prev_op.getOrder().setTotal(prev_op.getProduct().getPrice() + );
			prev_op.setQuantity(prev_op.getQuantity()+1);
		} else {
			OrdersProduct new_op = new OrdersProduct();
			new_op.setProduct(p);
			new_op.setQuantity(1);
	
			//new_op.getOrder().setTotal(p.getPrice());
		
			cart.put(p.getIdProducts(), new_op);			
		}
		
		
		
		return PAGE_SHOPPING_CART;
	}
	
	public float total() {
		Order ooo = new Order();
 		//wartość permanentna
 		Order ooo1 = new Order();
		
		cart.forEach((key, value) -> {
			ooo.setTotal(value.getProduct().getPrice() * value.getQuantity());
			ooo1.setTotal(ooo.getTotal() + ooo1.getTotal());			
		});
		order.setTotal(ooo1.getTotal());
		return ooo1.getTotal();
	}
	
	RemoteClient<Person> personRemote;
 	RemoteClient<Person> newpersonRemote;
 	
 	
	//ta metoda zapisze w bazie order
	public String createOrder() {
		
		//0. pobierz usera z sesji
		FacesContext facesContext = FacesContext.getCurrentInstance();
 		HttpSession session = (HttpSession) facesContext.getExternalContext().getSession(true);
 		newpersonRemote = personRemote.load(session);
 		
 		//loaded = (Person) session.getAttribute("person");
 		//newpersonRemote.getDetails();
 		if (newpersonRemote.getDetails() == null) {
			 System.out.println("XP");
		 }
 		if (newpersonRemote.getDetails() != null) {
			 System.out.println("IO");
		 }
 		
 		//wartość tymczasowa
 		Order ooo = new Order();
 		//wartość permanentna
 		Order ooo1 = new Order();
		
cart.forEach((key, value) -> {
			ooo.setTotal(value.getProduct().getPrice() * value.getQuantity());
			ooo1.setTotal(ooo.getTotal() + ooo1.getTotal());
		});
 		


LocalDateTime myDateObj = LocalDateTime.now();

order.setDateOrders(myDateObj);
        order.setPerson(newpersonRemote.getDetails());
 		order.setTotal(ooo1.getTotal());
 		
 		//order.setTotal(new_op1.getOrder().getTotal());
 		System.out.println(ooo1.getTotal());
 		//order.setTotal(ooo1.getTotal());

 		//zapis w bazie 
 		//orderDAO.createAndReturn(order);
 		//tworzymy instancje klasy  czyli nazwe nowego obiektu klasy, klasa musi być order bo orderDAO i metoda jest w Order
 		Order o = orderDAO.createAndReturn(order);
 		//pętlą po koszyku dodajemy do bd orders_products
 		//System.out.println("ID " + o.getIdOrders());
 			
 		
 		cart.forEach((key, value) -> {
 			
 			
 		    OrdersProductPK id = new OrdersProductPK();
 		    id.setOrdersIdOrders(o.getIdOrders());
 		    id.setProductsIdProducts(value.getProduct().getIdProducts());
 		    value.setId(id);
 		    
 		    
 			value.setOrder(o);
 			
 			
 			
 			//ordersProduct.setOrder(o);
 			//ordersProduct.setProduct(value.getProduct());
 			
 			//System.out.println("l"+ordersProduct.getProduct());
 			//System.out.println("2"+ordersProduct.getProduct().getName());
 			//ordersProduct.setQuantity(1);			
 			//zais w bazie
 			orderDAO.createOrdersProduct(value);
 			
 		});
 		
	
		return PAGE_SHOP;
	}
	
	
	//public String createOrder() {
	//	//0. pobierz usera z sesji
	//	
	//	//1.utwórz nowy Order
	//	//1.1 przypisz usera do order i datę
	//	//1.2 create order w BD tak żeby zwrócić obiekt z ID BD
	//	
	//	//2.pętla po koszyku (zmienna op)
	//	//  2.1 op.setOrder(order);
	//	//	2.2 orderProductDB.persist(op);
    //
	//	//cart.forEach((key, value) -> {
	//	//	
	//	//});
	//	
	//	return null;
	//}
	
	
	public String delete(Product p) {
		cart.remove(p.getIdProducts());
		
		return PAGE_SHOPPING_CART;
	}
	
	
}
