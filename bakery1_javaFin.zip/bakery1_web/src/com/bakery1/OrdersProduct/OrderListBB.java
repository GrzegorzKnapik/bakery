package com.bakery1.OrdersProduct;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.enterprise.context.RequestScoped;
import javax.ejb.EJB;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.servlet.http.HttpSession;

import com.bakery1.dao.OrderDAO;
import com.bakery1.dao.PersonDAO;
import com.bakery1.entities.Order;
import com.bakery1.entities.Person;
import com.bakery1.entities.Role;

import com.bakery1.dao.PersonDAO;
import com.bakery1.entities.Person;
import com.bakery1.entities.Role;
import com.bakery1.dao.RoleDAO;

import com.bakery1.entities.Order;
import com.bakery1.entities.OrdersProduct;
import com.bakery1.entities.OrdersProductPK;
import com.bakery1.entities.Person;
import com.bakery1.entities.Product;
import com.bakery1.person.LoginBB;
import com.bakery1.dao.OrderDAO;
import com.bakery1.dao.PersonDAO;
import com.bakery1.dao.OrdersProductDAO;

@Named
@RequestScoped
public class OrderListBB {
	private static final String PAGE_PERSON_EDIT = "personEdit?faces-redirect=true";
	private static final String PAGE_PERSON_ROLE_EDIT = "personRoleEdit?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;

	public OrderListBB() {
	}

	

	@Inject
	ExternalContext extcontext;

	@Inject
	Flash flash;
	
	@EJB
	OrdersProductDAO ordersProductDAO;

	
	
	

	
	

	public List<OrdersProduct> getFullList() {
		return ordersProductDAO.getFullList();
	}

	
	

	
}
