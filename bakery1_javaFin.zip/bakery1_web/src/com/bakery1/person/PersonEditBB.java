package com.bakery1.person;


import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.servlet.http.HttpSession;

import com.bakery1.dao.PersonDAO;
import com.bakery1.entities.Person;
import com.bakery1.entities.Role;
import com.bakery1.dao.RoleDAO;

@Named
@ViewScoped
public class PersonEditBB implements Serializable {
	private static final long serialVersionUID = 1L;

	private static final String PAGE_LOGIN = "login?faces-redirect=true";
	private static final String PAGE_PERSON_LIST = "personList?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;

	private Person person = new Person();

	private Person loaded = null;
	
	

	
	
	@EJB
	PersonDAO personDAO;
	
	@EJB
	RoleDAO roleDAO;

	@Inject
	FacesContext context;

	@Inject
	Flash flash;

	public Person getPerson() {
		return person;
	}
	

	public void onLoad() throws IOException {
		// 1. load person passed through session
		// HttpSession session = (HttpSession) context.getExternalContext().getSession(true);
		// loaded = (Person) session.getAttribute("person");

		// 2. load person passed through flash
		loaded = (Person) flash.get("person");
		
		// cleaning: attribute received => delete it from session
		if (loaded != null) {
			person = loaded;
			// session.removeAttribute("person");
		} else {
			context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Błędne użycie systemu", null));
			// if (!context.isPostback()) { //possible redirect
			// context.getExternalContext().redirect("personList.xhtml");
			// context.responseComplete();
			// }
		}

	}
	
	public String saveRoleData() {
		// no Person object passed
		if (loaded == null) {
			return PAGE_STAY_AT_THE_SAME;
		}

		try {
			if (person.getIdPerson() != null) {
				
				
				
				Map<String, Object> searchParams = new HashMap<String, Object>();
				searchParams.put("typeRole", person.getRole().getTypeRole());
				
				Role role = roleDAO.getList(searchParams).get(0);
				
				
				person.setRole(role);
				
				personDAO.merge(person);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			context.addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "wystąpił błąd podczas zapisu", null));
			return PAGE_STAY_AT_THE_SAME;
		}

		return PAGE_PERSON_LIST;
	}
	
	
	
	

	public String saveData() {
		// no Person object passed
		if (loaded == null) {
			return PAGE_STAY_AT_THE_SAME;
		}
		
	

		try {
			if (person.getIdPerson() == null) {
				// new record
				//person.setRole(null);
				FacesContext ctx = FacesContext.getCurrentInstance();
				Map<String, Object> searchParams1 = new HashMap<String, Object>();
				searchParams1.put("numberLogin", person.getNumberLogin());
				List<Person> personListLR = personDAO.getListLoginRepeat(searchParams1);
				
				if(!personListLR.isEmpty()) {
		    		//ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, txtLogin.getString("invalidLogIn"), null));
		    		ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Taki numer już istnieje, podaj inny numer", null));
		    		 return PAGE_STAY_AT_THE_SAME;
		    	}
				
				
				
				
				
				Map<String, Object> searchParams = new HashMap<String, Object>();
				searchParams.put("typeRole", "klient");
				
				Role role = roleDAO.getList(searchParams).get(0);
				
				
				
				person.setRole(role);
				//zapis w bazie
				personDAO.create(person);
				
				
			} else {
				// existing record
				personDAO.merge(person);
			}
		} catch (Exception e) {
			e.printStackTrace();
			context.addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "wystąpił błąd podczas zapisu", null));
			return PAGE_STAY_AT_THE_SAME;
		}

		//return PAGE_PERSON_LIST;
		return PAGE_LOGIN;
	}
}
