package com.bakery1.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the person database table.
 * 
 */
@Entity
@NamedQuery(name="Person.findAll", query="SELECT p FROM Person p")
public class Person implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column
	private Integer id_person;

	private String name;

	@Column
	private Integer number_login;

	private String password;

	private String surname;

	//bi-directional many-to-one association to Order
	@OneToMany(mappedBy="person")
	private List<Order> orders;

	//bi-directional many-to-one association to Role
	@ManyToOne
	private Role role;

	public Person() {
	}

	public Integer getId_person() {
		return this.id_person;
	}

	public void setId_person(Integer id_person) {
		this.id_person = id_person;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getNumber_login() {
		return this.number_login;
	}

	public void setNumber_login(Integer number_login) {
		this.number_login = number_login;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSurname() {
		return this.surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public List<Order> getOrders() {
		return this.orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}

	public Order addOrder(Order order) {
		getOrders().add(order);
		order.setPerson(this);

		return order;
	}

	public Order removeOrder(Order order) {
		getOrders().remove(order);
		order.setPerson(null);

		return order;
	}

	public Role getRole() {
		return this.role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

}