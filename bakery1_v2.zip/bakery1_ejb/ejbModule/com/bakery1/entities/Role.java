package com.bakery1.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the role database table.
 * 
 */
@Entity
@NamedQuery(name="Role.findAll", query="SELECT r FROM Role r")
public class Role implements Serializable {
	private static final long serialVersionUID = 1L;

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true, nullable = false)
	private Integer id_role;
	

	//@Column(name="type_role")
	//private String type_role;
	
	@Column(length = 45)
	private String type_role;


	//bi-directional many-to-one association to Person
	@OneToMany(mappedBy="role")
	private List<Person> persons;
	
	public void log(String text) {
		System.out.println(text + ": [" + id_role + "], " + type_role);
	}

	public Role() {
	}

	public Integer getId_role() {
		return this.id_role;
	}

	public void setId_role(Integer id_role) {
		this.id_role = id_role;
	}

	public String getType_role() {
		return this.type_role;
	}

	public void setType_role(String type_role) {
		this.type_role = type_role;
	}

	public List<Person> getPersons() {
		return this.persons;
	}

	public void setPersons(List<Person> persons) {
		this.persons = persons;
	}

	public Person addPerson(Person person) {
		getPersons().add(person);
		person.setRole(this);

		return person;
	}

	public Person removePerson(Person person) {
		getPersons().remove(person);
		person.setRole(null);

		return person;
	}

}