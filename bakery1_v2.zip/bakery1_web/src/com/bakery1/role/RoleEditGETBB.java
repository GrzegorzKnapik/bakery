package com.bakery1.role;

import java.io.IOException;
import java.io.Serializable;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.bakery1.dao.RoleDAO;
import com.bakery1.entities.Role;

@Named
@ViewScoped
public class RoleEditGETBB implements Serializable {
	private static final long serialVersionUID = 1L;

	private static final String PAGE_ROLE_LIST = "roleList?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;

	private Role role = new Role();
	private Role loaded = null;

	@Inject
	FacesContext context;

	@EJB
	RoleDAO roleDAO;

	public Role getRole() {
		return role;
	}

	public void onLoad() throws IOException {
		if (!context.isPostback()) {
			if (!context.isValidationFailed() && role.getId_role() != null) {
				loaded = roleDAO.find(role.getId_role());
			}
			if (loaded != null) {
				role = loaded;
			} else {
				context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Błędne użycie systemu", null));
				// if (!context.isPostback()) { // possible redirect
				// context.getExternalContext().redirect("personList.xhtml");
				// context.responseComplete();
				// }
			}
		}

	}

	public String saveData() {
		// no Person object passed
		if (loaded == null) {
			return PAGE_STAY_AT_THE_SAME;
		}

		try {
			if (role.getId_role() == null) {
				// new record
				roleDAO.create(role);
			} else {
				// existing record
				roleDAO.merge(role);
			}
		} catch (Exception e) {
			e.printStackTrace();
			context.addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "wystąpił błąd podczas zapisu", null));
			return PAGE_STAY_AT_THE_SAME;
		}

		return PAGE_ROLE_LIST;
	}
}
