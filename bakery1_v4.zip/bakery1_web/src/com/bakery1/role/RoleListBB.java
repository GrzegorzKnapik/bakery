package com.bakery1.role;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.ejb.EJB;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.servlet.http.HttpSession;

import com.bakery1.dao.RoleDAO;
import com.bakery1.entities.Role;

@Named
@RequestScoped
public class RoleListBB {
	private static final String PAGE_ROLE_EDIT = "roleEdit?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;

	private String type_role;

	@Inject
	ExternalContext extcontext;

	@Inject
	Flash flash;

	@EJB
	RoleDAO roleDAO;

	public String getType_role() {
		return type_role;
	}

	public void setType_role(String type_role) {
		this.type_role = type_role;
	}

	public List<Role> getFullList() {
		return roleDAO.getFullList();
	}

	public List<Role> getList() {
		List<Role> list = null;

		// 1. Prepare search params
		Map<String, Object> searchParams = new HashMap<String, Object>();

		if (type_role != null && type_role.length() > 0) {
			searchParams.put("type_role", type_role);
		}

		// 2. Get list
		list = roleDAO.getList(searchParams);

		return list;
	}

	public String newRole() {
		Role role = new Role();

		// 1. Pass object through session
		// HttpSession session = (HttpSession) extcontext.getSession(true);
		// session.setAttribute("person", person);

		// 2. Pass object through flash
		flash.put("role", role);

		return PAGE_ROLE_EDIT;
	}

	public String editRole(Role role) {
		// 1. Pass object through session
		// HttpSession session = (HttpSession) extcontext.getSession(true);
		// session.setAttribute("person", person);

		// 2. Pass object through flash
		flash.put("role", role);

		return PAGE_ROLE_EDIT;
	}

	public String deleteRole(Role role) {
		roleDAO.remove(role);
		return PAGE_STAY_AT_THE_SAME;
	}
}
