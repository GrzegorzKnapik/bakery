package com.bakery1.OrdersProduct;


import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.faces.simplesecurity.RemoteClient;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.bakery1.entities.Order;
import com.bakery1.entities.OrdersProduct;
import com.bakery1.entities.Person;
import com.bakery1.entities.Product;
import com.bakery1.person.LoginBB;
import com.bakery1.dao.OrderDAO;
import com.bakery1.dao.PersonDAO;

@Named
@SessionScoped
public class ShopBB implements Serializable {
	private static final long serialVersionUID = 1L;

	private static final String PAGE_SHOPPING_CART = "shoppingCart?faces-redirect=true";
	private static final String PAGE_HELLO = "hello?faces-redirect=true";
	private static final String PAGE_PERSON_LIST = "personList?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;
	
	
	private Order order = new Order();
	private Person loaded = null;
	
	@Inject
	FacesContext context;
	
	
	@Inject
	Flash flash;
	
	@EJB
	OrderDAO orderDAO;
	
	public void onLoad() throws IOException {
		// 1. load person passed through session
		
		 HttpSession session = (HttpSession) context.getExternalContext().getSession(true);
		 loaded = (Person) session.getAttribute("person");
		 
		 if (loaded != null) {
			 System.out.println("sssss");
		 }
		 order.setPerson(loaded);

		 if (loaded == null) {
			 System.out.println("ssesss");
		 }
		 
				 
		// 2. load person passed through flash
		//loaded = (Person) flash.get("person");

		// cleaning: attribute received => delete it from session
		//if (loaded != null) {
		//	person = loaded;
			// session.removeAttribute("person");
		//} else {
		//	context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Błędne użycie systemu", null));
			// if (!context.isPostback()) { //possible redirect
			// context.getExternalContext().redirect("personList.xhtml");
			// context.responseComplete();
			// }
		//}

	}
	
	
	
	
	
	
	private HashMap<Integer,OrdersProduct> cart;
	
	
	@PostConstruct
	public void init() {
			this.cart = new HashMap<Integer,OrdersProduct>();
	}
	
	public HashMap<Integer,OrdersProduct> getItems() {
		return cart;
	}
	
	public List<OrdersProduct> getList() {
		ArrayList<OrdersProduct> list = new ArrayList<OrdersProduct>();
		cart.forEach((key, value) -> {
			list.add(value);
		});
		return list;
	}
	
	
	public String addToCart(Product p) {
		
		//1. czy istnieje już taki produkt
		
		if(cart.containsKey(p.getIdProducts())) {
			OrdersProduct prev_op = cart.get(p.getIdProducts());
			prev_op.setQuantity(prev_op.getQuantity()+1);
		} else {
			OrdersProduct new_op = new OrdersProduct();
			new_op.setProduct(p);
			new_op.setQuantity(1);
			cart.put(p.getIdProducts(), new_op);
			///
			 
			
		}
		//createOrder();
		
		return PAGE_SHOPPING_CART;
	}
	RemoteClient<Person> personRemote;
 	RemoteClient<Person> newpersonRemote;
 	
 	
	//ta metoda zapisze w bazie order
	public String createOrder() {
		//0. pobierz usera z sesji
		//HttpSession session = (HttpSession) context.getExternalContext().getSession(true);
		//		loaded = (Person) session.getAttribute("person");
		
				
		//		if (loaded == null) {
		//			 System.out.println("X");
		//		 }
		
		//0. pobierz usera z sesji
		FacesContext facesContext = FacesContext.getCurrentInstance();
 		HttpSession session = (HttpSession) facesContext.getExternalContext().getSession(true);
 		newpersonRemote = personRemote.load(session);
 		
 		//loaded = (Person) session.getAttribute("person");
 		//newpersonRemote.getDetails();
 		if (newpersonRemote.getDetails() == null) {
			 System.out.println("XP");
		 }
 		if (newpersonRemote.getDetails() != null) {
			 System.out.println("IO");
		 }
			
 		order.setPerson(newpersonRemote.getDetails());
 		order.setDateOrders(99);
 		order.setTotal(99);
 		
 		//zapis w bazie 
 		orderDAO.createAndReturn(order);
 		//pętlą po koszyku dodajemy do bd orders_products
 		
 		
	
		return null;
	}
	
	
	//public String createOrder() {
	//	//0. pobierz usera z sesji
	//	
	//	//1.utwórz nowy Order
	//	//1.1 przypisz usera do order i datę
	//	//1.2 create order w BD tak żeby zwrócić obiekt z ID BD
	//	
	//	//2.pętla po koszyku (zmienna op)
	//	//  2.1 op.setOrder(order);
	//	//	2.2 orderProductDB.persist(op);
    //
	//	//cart.forEach((key, value) -> {
	//	//	
	//	//});
	//	
	//	return null;
	//}
	
	
	public String delete(Product p) {
		cart.remove(p.getIdProducts());
		
		return PAGE_SHOPPING_CART;
	}
	
	
}
