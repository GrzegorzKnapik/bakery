package bakery1.dao;

import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import bakery1.entities.Role;

//DAO - Data Access Object for Role entity
//Designed to serve as an interface between higher layers of application and data.
//Implemented as stateless Enterprise Java bean - server side code that can be invoked even remotely.

@Stateless
public class RoleDAO {
	private final static String UNIT_NAME = "bakery1-simplePU";

	// Dependency injection (no setter method is needed)
	@PersistenceContext(unitName = UNIT_NAME)
	protected EntityManager em;

	public void create(Role role) {
		em.persist(role);
	}

	public Role merge(Role role) {
		return em.merge(role);
	}

	public void remove(Role role) {
		em.remove(em.merge(role));
	}

	public Role find(Object id) {
		return em.find(Role.class, id);
	}

	public List<Role> getFullList() {
		List<Role> list = null;

		Query query = em.createQuery("select p from Role p");

		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	public List<Role> getList(Map<String, Object> searchParams) {
		List<Role> list = null;

		// 1. Build query string with parameters
		String select = "select p ";
		String from = "from Role p ";
		String where = "";
		//String orderby = "order by p.typeRole asc, p.typeRole";

		// search for surname
		String typeRole = (String) searchParams.get("typeRole");
		if (typeRole != null) {
			if (where.isEmpty()) {
				where = "where ";
			} else {
				where += "and ";
			}
			where += "p.typeRole like :typeRole ";
		}
		
		// ... other parameters ... 

		// 2. Create query object
		Query query = em.createQuery(select + from + where);

		// 3. Set configured parameters
		if (typeRole != null) {
			query.setParameter("typeRole", typeRole+"%");
		}

		// ... other parameters ... 

		// 4. Execute query and retrieve list of Role objects
		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

}
