package bakery1.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the orders_products database table.
 * 
 */
@Embeddable
public class OrdersProductPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="products_id_products", insertable=false, updatable=false)
	private int productsIdProducts;

	@Column(name="orders_id_orders", insertable=false, updatable=false)
	private int ordersIdOrders;

	public OrdersProductPK() {
	}
	public int getProductsIdProducts() {
		return this.productsIdProducts;
	}
	public void setProductsIdProducts(int productsIdProducts) {
		this.productsIdProducts = productsIdProducts;
	}
	public int getOrdersIdOrders() {
		return this.ordersIdOrders;
	}
	public void setOrdersIdOrders(int ordersIdOrders) {
		this.ordersIdOrders = ordersIdOrders;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof OrdersProductPK)) {
			return false;
		}
		OrdersProductPK castOther = (OrdersProductPK)other;
		return 
			(this.productsIdProducts == castOther.productsIdProducts)
			&& (this.ordersIdOrders == castOther.ordersIdOrders);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.productsIdProducts;
		hash = hash * prime + this.ordersIdOrders;
		
		return hash;
	}
}